/* global console */
'use strict'

window.Element.prototype.__setAttribute = window.Element.prototype.setAttribute
window.Element.prototype.setAttribute = function (attrName, fn) { 
  console.log('__setAttribute start')
  if (attrName.indexOf(':on') === 0) {
    let elem = this
    // 注：chrome禁止将:onclick="alert(123)"中
    // 的alert(123)字符串通过eval或Fuction转换为function
    fixEventHandler(elem, attrName, fn)
  }
  else this.__setAttribute(attrName, fn)
  console.log('__setAttribute finish')
}
window.Element.prototype.html = function (str) {
  this.innerHTML = str
  this.bindEvent()
}
window.Element.prototype.bindEvent = function () {
  let list = document.getElementsByTagName('*')
  for (let i = 0, len = list.length; i < len; i++) {
    let elem = list[i]
    let attrs = elem.attributes
    if (!attrs) continue
    for (let k = 0, len2 = attrs.length; k < len2; k++) {
      let field = attrs[k]
      if (!field || !field.nodeName || field.nodeName.indexOf(':on') !== 0) continue
      fixEventHandler(elem, field.nodeName, field.nodeValue)
    }
  }
}

function fixEventHandler(elem, evtName, fn) {
  evtName = evtName.replace(':on', 'on')
  // 注：chrome禁止将:onclick="alert(123)"中
  // 的alert(123)字符串通过eval或Fuction转换为function
  // 注：已绑则无需重复绑
  if (elem[evtName]) return ''
  if (typeof fn === 'function') {
    elem[evtName] = fn
    return ''
  }
  if (typeof fn !== 'string') return ''
  if (fn.split('(').length !== 2 || fn.split(')').length !== 2) throw new Error('Only support like :onclick="page.changeIndex(this, \'up\', false)"')
  let s1 = fn.split('(')[0].trim()
  let s2 = fn.split('(')[1].split(')')[0].trim()
  // page['addRule'].dd["aa"]
  let arr = s1.replace(/['"\]]/g,'').replace(/\[/g, '.').split('.')

  let parent = window
  while (arr.length) {
    let cc = arr.shift().trim()
    if (!parent[cc]) throw new Error('Only support like :onclick="page.changeIndex(this, \'up\', false)"')
    parent = parent[cc]
  }
  // (this, 'up', false)
  let thus = false
  s2 = s2.replace(/^this\s+/, 'this')
  if (s2 === 'this' || s2.indexOf('this,') > -1) {
    thus = true
    s2 = s2.replace(/^this,?/, '')
  }
  s2 = s2.replace(/\"/g, '\\"').replace(/\'/g, '"')
  let args
  try {
    args = JSON.parse('[' + s2 + ']')
  } catch (err) {
    throw new Error('Only support like :onclick="page.changeIndex(this, \'up\', false)"')
  }
  if (thus) args.unshift(elem)

  elem[evtName] = function (...params) {
    parent(...params)
  }.bind(elem, ...args)
}