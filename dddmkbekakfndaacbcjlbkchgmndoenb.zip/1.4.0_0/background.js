/* global chrome */
'use strict'

var GoResMap = []
var typeMap = {
  "txt": "text/plain",
  "htm": "text/html",
  "html": "text/html",
  "css": "text/css",
  "js": "text/javascript",
  "json": "text/json",
  "xml": "text/xml",
  "jpg": "image/jpeg",
  "gif": "image/gif",
  "png": "image/png",
  "webp": "image/webp"
}

function getLocalStorage() {
  chrome.storage.local.get(['GoResMap'], function (result2) {
    GoResMap = result2.GoResMap ? JSON.parse(result2.GoResMap) : GoResMap
  })
}
getLocalStorage()

/*
Fiddler 自动响应的规则定义

普通字符串 hello.com // 匹配url包含 hello.com 的
通配符 * // 匹配所有url
NOT: hello // 匹配url不包含hello的
EXACT: http://localhost/test.php?foo=BAR //精确匹配 包括大小写
正则 regex:(?inxs)http://localhost/\w+\.php 如: regex:.+, regex:.+jpg, regex:.+(gif|png|jpg)$
正则支持修饰符 inxs
i ignore case 忽略大小写
n requires explicit capture groups 要求明确的捕获组（未命名捕获组将会被忽略）
s enables single-line syntax 单行
x enables comments after the #character 支持#后加注释 （JS暂时不支持带注释(?#注释)）
*/
var matchCounts = {}
chrome.webRequest.onBeforeRequest.addListener(function (curtab) {
  getLocalStorage()

  var url = curtab.url
  if (url.indexOf('chrome-extension://') === 0) return {}

  matchCounts[curtab.tabId] = matchCounts[curtab.tabId] || {}
  matchCounts[curtab.tabId].count = matchCounts[curtab.tabId].count || 0


  var isMatched = false
  var result = {}
  // Let it go if "chrome-extension://"
  for (var i = 0, len = GoResMap.length; i < len; i++) {
    var rule = GoResMap[i]
    if (!rule.enable) continue;

    // C:\00work\tmp => file:///C:/00work/tmp/
    if (/^[a-zA-Z]:\\/.test(rule.target)) rule.target = 'file:///' + rule.target.split('\\').join('/')

    // 注：规则判断
    if (rule.type === 'REPLACE' && url.toLowerCase().indexOf(rule.into.toLowerCase()) > -1) {
      isMatched = true
      break
    }
    if (rule.type === 'INCLUDE' && url.toLowerCase().indexOf(rule.into.toLowerCase()) > -1) {
      isMatched = true
      break
    }
    if (rule.type === 'EXACT' && url === rule.into) {
      isMatched = true
      break
    }
    if (rule.type === 'REGEX') {
      var reg = new RegExp(rule.into, '')
      var href = String(rule.target || '').trim()
      if (href && reg.test(url)) {
        isMatched = true
        break
      }
    }
  }

  if (isMatched) {
    matchCounts[curtab.tabId].count++

    chrome.tabs.get(curtab.tabId, function (tab) {
      if (tab && tab.active) {
        matchCounts[tab.id] = matchCounts[tab.id] || {}
        var str = String(matchCounts[tab.id].count || '')
        chrome.action.setBadgeText({ text: str })
        chrome.action.setBadgeBackgroundColor({ color: '#646464' })
      }
    })
  }
}, {
  urls: ["<all_urls>"]
}, [])

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (tab.url.indexOf('chrome-extension://') > -1) return ''
  if (tab.url.indexOf('chrome://') > -1) return ''

  matchCounts[tabId] = matchCounts[tabId] || {}
  if (matchCounts[tabId].status === 'complete' && tab.status === 'loading') {
    matchCounts[tabId].count = 0
    chrome.action.setBadgeText({ text: '' })
  }
  matchCounts[tabId].status = tab.status
})

chrome.tabs.onActivated.addListener(function (curtab) {
  for (var i in matchCounts) {
    if (!matchCounts.hasOwnProperty(i)) continue
    matchCounts[i].active = false
  }
  if (!matchCounts[curtab.tabId]) {
    chrome.action.setBadgeText({ text: '' })
    return ''
  }

  matchCounts[curtab.tabId].active = true
  matchCounts[curtab.tabId].count = matchCounts[curtab.tabId].count || 0
  var str = String(matchCounts[curtab.tabId].count || '')

  chrome.action.setBadgeText({ text: str })
  chrome.action.setBadgeBackgroundColor({ color: '#646464' })
})

chrome.declarativeNetRequest.updateDynamicRules({
  removeRuleIds: [1001, 1002, 1003, 1004]
})