/* global chrome, hui */
'use strict'

var page = {}
window.page = page

//保存规则数据到localStorage
page.saveData = function () {
  chrome.storage.local.set({ 'GoResMap': JSON.stringify(page.ruleMaps) })
  page.showInfo('')
  window.setTimeout(function () {
    page.showInfo('数据保存成功', 'success')
  }, 50)

  page.updateDynamicRules()
}
page.getData = function (callback) {
  chrome.storage.local.get(['GoResMap'], function (result) {
    var data = JSON.parse(result.GoResMap || '[]')
    page.ruleMaps = data
    page.ruleMapsOrigin = JSON.parse(JSON.stringify(page.ruleMaps))

    callback()
  })
}

// 点击添加按钮
page.addRule = function () {
  var curRule = {
    enable: 'checked',
    sid: '',
    type: 'EXACT',
    into: 'abc',
    target: 'abc'
  }
  curRule.sid = hui.formatDate(new Date(), 'MMddHHmm') + '_' + Number(Math.round((1 + Math.random()) * 10000)).toString(16)

  page.ruleMaps.push(curRule)
  page.flushList()
  page.showChange()
}

page.beginNumber = page.curRuleIndex = 10000
page.clearDynamicRule = function () {
  var ids = []
  for (var i = 0, len = page.curRuleIndex; i < len; i++) { ids.push(i) }
  chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds: ids })
}

page.updateDynamicRules = function (list) {
  chrome.storage.local.get(['GoResMap'], function (result) {
    var data = JSON.parse(result.GoResMap || '[]')
    page.curRuleIndex = Math.max(page.curRuleIndex, page.beginNumber + data.length)
    page.clearDynamicRule()

    for (var i = 0, len = data.length; i < len; i++) {
      if (data[i].enable !== 'checked') continue
      if (data[i].type === 'INCLUDE') page.createIncludeRule(data[i], page.beginNumber + i)
      else if (data[i].type === 'EXACT') page.createExactRule(data[i], page.beginNumber + i)
      else if (data[i].type === 'REGEX') page.createRegexRule(data[i], page.beginNumber + i)
      else if (data[i].type === 'REPLACE') page.createReplaceRule(data[i], page.beginNumber + i)
    }
  })
}

page.showInfo = function (str, type) {
  var errorMsg = document.getElementById('errorMsg')
  var msgBox = errorMsg.parentNode
  var elem = errorMsg.parentNode.parentNode.parentNode
  elem.style.display = !str ? 'none' : ''
  hui.removeClass(msgBox, 'alert-danger alert-success', type === 'success' ? 'alert-success' : 'alert-danger')
  errorMsg.innerText = str

  if (errorMsg.timer) window.clearTimeout(errorMsg.timer)
  errorMsg.timer = null
  if (str) errorMsg.timer = window.setTimeout(function () {
    page.showInfo('')
  }, 2500)
}
//验证输入合法性
page.verify = function () {
  var result = true
  hui.removeClass('.has-error', 'has-error')
  for (var i = page.ruleMaps.length - 1; i > -1; i--) {
    var curRule = page.ruleMaps[i]
    var row = document.querySelector('.row_' + curRule.sid)
    var into = row.querySelector('.into')
    var target = row.querySelector('.target')
    if (!curRule.into) {
      hui.addClass(into.parentNode, 'has-error')
      into.title = '匹配条件不能为空'
      result = false
    } else if (curRule.type === 'REGEX') {
      try {
        new RegExp(curRule.into)
      } catch (e) {
        hui.addClass(into.parentNode, 'has-error')
        into.title = '正则格式错误'
        result = false
      }
    }
    if (!curRule.target) {
      hui.addClass(target.parentNode, 'has-error')
      target.title = '跳转地址不能为空'
      result = false
    }
    // else if (curRule.type !== 'REGEX' && curRule.target.replace(/^\s*[a-zA-Z]+:/, '') === curRule.target) {
    //   hui.addClass(target.parentNode, 'has-error')
    //   target.title = '跳转地址不是有效URL'
    //   result = false
    // }
  }
  if (!result) page.showInfo('请更正列表中的错误')
  return result
}

page.showChange = function () {
  // if (hui.isEqual(page.ruleMapsOrigin, page.ruleMaps)) {
  //   // hui.removeClass('#btnSave', 'btn-success', 'btn-default')
  //   // document.getElementById('btnSave').style.display = 'none'
  // } else {
  //   // document.getElementById('btnSave').style.display = 'inline-block'
  //   // hui.removeClass('#btnSave', 'btn-default', 'btn-success')
  page.saveRule()
  // }
}

page.getParentSid = function (elem) {
  if (!elem) return ''
  var sid = ''
  while (elem) {
    if (elem.hasAttribute('sid')) {
      sid = elem.getAttribute('sid')
      break
    } else {
      elem = elem.parentNode
    }
  }
  return sid
}

//点击复制按钮
page.copyRule = function (elem) {
  var sid = page.getParentSid(elem)

  for (var i = page.ruleMaps.length - 1; i > -1; i--) {
    if (sid === page.ruleMaps[i].sid) {
      var curRule = Object.assign({}, page.ruleMaps[i])
      curRule.sid = hui.formatDate(new Date(), 'MMddHHmm') + '_' + Number(Math.round((1 + Math.random()) * 10000)).toString(16)
      curRule.enable = 'checked'

      page.ruleMaps.push(curRule)
      page.flushList()
      page.showChange()
      page.flushList()
    }
  }
}

//启用/禁用规则
page.enableRule = function (elem) {
  var sid = page.getParentSid(elem)
  for (var i = page.ruleMaps.length - 1; i > -1; i--) {
    if (sid === page.ruleMaps[i].sid) {
      page.ruleMaps[i].enable = !page.ruleMaps[i].enable ? 'checked' : ''
    }
  }
  page.showChange()
  page.flushList()
}

page.changeValue = function (elem, field) {
  var sid = page.getParentSid(elem)
  for (var i = page.ruleMaps.length - 1; i > -1; i--) {
    if (sid === page.ruleMaps[i].sid) {
      page.ruleMaps[i][field] = elem.value
    }
  }
  page.showChange()
  page.flushList()
}

page.clearInput = function (elem) {
  elem.previousElementSibling.value = ''
  elem.previousElementSibling.focus()
  page.verify()
}

page.changeIndex = function (elem) {
  var sid = page.getParentSid(elem)
  var sign = elem.className.indexOf('btn-moveup') > -1 ? 'up' : 'down'
  for (var i = page.ruleMaps.length - 1; i > -1; i--) {
    if (sid === page.ruleMaps[i].sid) {
      var cur = page.ruleMaps[i]
      if (sign === 'up' && i > 0) {
        page.ruleMaps[i] = page.ruleMaps[i - 1]
        page.ruleMaps[i - 1] = cur
      }
      if (sign === 'down' && i < page.ruleMaps.length - 1) {
        page.ruleMaps[i] = page.ruleMaps[i + 1]
        page.ruleMaps[i + 1] = cur
      }
      break
    }
  }
  page.showChange()
  page.flushList()
}

//删除规则
page.removeRule = function (elem) {
  var sid = page.getParentSid(elem)
  for (var i = page.ruleMaps.length - 1; i > -1; i--) {
    if (sid === page.ruleMaps[i].sid) {
      page.ruleMaps.splice(i, 1)
    }
  }
  page.showChange()
  page.flushList()
}
//保存按钮点击事件
page.saveRule = function () {
  if (page.verify()) {
    page.saveData()
    page.refresh()
  }
}
//清空规则
page.clearRule = function () {
  page.ruleMaps = []
  page.saveData()
  page.refresh()
}

page.flushList = function () {
  /////
  // var tpl2 = `
  //   <tr>
  //     <td width="8%"><input sid="{{sid}}" type="checkbox" class="checked" {{enable}}/></td>
  //     <td width="7%">{{type}} :</td>
  //     <td width="35%"><div>{{into}}</div></td>
  //     <td width="35%"><div>{{target}}</div></td>
  //     <td width="15%">
  //       <button sid="{{sid}}" type="button" class="btn btn-primary btn-xs edit">编辑</button>
  //       <button sid="{{sid}}" type="button" class="btn btn-default btn-xs remove">删除</button>
  //     </td>
  //   </tr>`
  var tpl = `
    <tr sid="{{sid}}" class="row-rule row_{{sid}} type_{{type}}">
      <td>
        <button tabindex="0" class="ivu-switch ivu-switch-default ivu-switch-{{enable}}" :onclick="page.enableRule(this)">
          <span class="ivu-switch-inner"><span class="on">开</span> <span class="off">关</span></span>
        </button>
      </td>
      <td class="sort-bar">
        <button class="btn btn-default btn-sm btn-moveup" :onclick="page.changeIndex(this, 'up')"><span class="glyphicon glyphicon-arrow-up"></span></button>
        <button class="btn btn-default btn-sm btn-movedown" :onclick="page.changeIndex(this, 'down')"><span class="glyphicon glyphicon-arrow-down"></span></button>
      </td>
      <td>
        <select name="type" class="btn btn-default dropdown-toggle type" :onchange="page.changeValue(this, 'type')">
          <option value="REPLACE" {{selected_REPLACE}}>替换</option>
          <option value="INCLUDE" {{selected_INCLUDE}}>包含</option>
          <option value="EXACT" {{selected_EXACT}}>等于</option>
          <option value="REGEX" {{selected_REGEX}}>正则</option>
        </select>
      </td>
      <td>
        <div class="clearable">
        <input required="required" type="search" class="form-control into" value="{{into}}" :onchange="page.changeValue(this, 'into')" />
        <span class="clear-x" :onclick="page.clearInput(this)"> </span>
        </div>
      </td>
      <td>
        <div class="clearable">
        <input required="required" type="search" class="form-control target" value="{{target}}" :onchange="page.changeValue(this, 'target')" />
        <span class="clear-x" :onclick="page.clearInput(this)"> </span>
        </span>
      </td>
      <td>
        <button title="Delete" class="btn btn-danger btn-sm remove" :onclick="page.removeRule(this)"><span class="glyphicon glyphicon-trash"></span></button>
        <button title="Copy" class="btn btn-default btn-sm copy" :onclick="page.copyRule(this)"><span class="glyphicon glyphicon-duplicate"></span></button>
      </td>
    </tr>`

  // var keys = {
  //   'REPLACE': '替换',
  //   'EXACT': '等于',
  //   'INCLUDE': '包含',
  //   'REGEX': '正则'
  // }
  var result = []
  for (var i = 0, len = page.ruleMaps.length; i < len; i++) {
    var item = page.ruleMaps[i]
    var data = {}
    data.selected_REPLACE = ''
    data.selected_INCLUDE = ''
    data.selected_EXACT = ''
    data.selected_REGEX = ''
    data['selected_' + item.type] = 'selected'

    data.sid = item.sid
    data.enable = item.enable
    data.type = item.type
    data.into = item.into
    data.target = item.target
    var str = hui.format(tpl, data)
    // if (i > 0) str = str.replace(/\swidth="\d+%"/ig, '')
    result.push(str)
  }
  var ruleList = document.getElementById('ruleList')
  ruleList.html(result.join('\n'))
}

//导出
page.exportRules = function () {
  function saveAs(blob, filename) {
    var type = blob.type
    var force_saveable_type = 'application/octet-stream'
    if (type && type != force_saveable_type) { // 强制下载，而非在浏览器中打开
      var slice = blob.slice || blob.webkitSlice
      blob = slice.call(blob, 0, blob.size, force_saveable_type)
    }

    var url = URL.createObjectURL(blob)
    var save_link = document.createElementNS('http://www.w3.org/1999/xhtml', 'a')
    save_link.href = url
    save_link.download = filename

    var event = document.createEvent('MouseEvents')
    event.initMouseEvent('click', true, false, window, 0, 0, 0, 0, 0, false, false, false, false, 0, null)
    save_link.dispatchEvent(event)
    URL.revokeObjectURL(url)
  }

  var URL = URL || window.webkitURL || window
  var bb = new Blob([JSON.stringify(page.ruleMaps, null, '\t')], {
    type: 'text/json'
  })
  saveAs(bb, 'GoResSetting.json')
}

//导入
document.getElementById('jsonFile').onchange = function () {
  var resultFile = this.files[0]
  if (resultFile) {
    var reader = new FileReader()
    reader.readAsText(resultFile)
    reader.onload = function () {
      try {
        var data = JSON.parse(this.result)
        page.ruleMaps.length = 0
        for (var i = 0, len = data.length; i < len; i++) {
          page.ruleMaps.push(data[i])
        }
        page.saveData()
        page.refresh()
        page.showInfo('导入成功', 'success')
      } catch (e) {
        page.showInfo('导入失败，请检查文件格式是否正确')
      }
    }
  }
}

page.refresh = function () {
  page.getData(function () {
    // page.showChange()
    page.flushList()
    // page.showInfo('')
  })
}

page.refresh()

page.createIncludeRule = function (item, ruleIndex) {
  // 包含 ok
  chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [{
      'id': ruleIndex,
      'priority': 1,
      'action': {
        'type': 'redirect',
        'redirect': {
          url: item.target
        }
      },
      'condition': {
        'urlFilter': item.into,
        'resourceTypes': [
          'csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script',
          'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'webtransport', 'xmlhttprequest'
        ]
      }
    }]
  })
}
page.createExactRule = function (item, ruleIndex) {
  // 等于 ok
  chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [{
      'id': ruleIndex,
      'priority': 1,
      'action': {
        'type': 'redirect',
        'redirect': {
          url: item.target
        }
      },
      'condition': {
        'urlFilter': '|' + item.into.trim() + '|',
        'resourceTypes': [
          'csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script',
          'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'webtransport', 'xmlhttprequest'
        ]
      }
    }]
  })
}
page.createReplaceRule = function (item, ruleIndex) {
  // 替换 ok
  chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [{
      'id': ruleIndex,
      'priority': 1,
      'action': {
        'type': 'redirect',
        'redirect': {
          'regexSubstitution': '\\1' + item.target.trim() + '\\2'
        }
      },
      'condition': {
        'regexFilter': '(.*)' + item.into + '(.*)',
        'resourceTypes': [
          'csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script',
          'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'webtransport', 'xmlhttprequest'
        ]
      }
    }]
  })
}
page.createRegexRule = function (item, ruleIndex) {
  // 正则
  chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [{
      'id': ruleIndex,
      'priority': 1,
      'action': {
        'type': 'redirect',
        'redirect': {
          url: item.target
        }
      },
      'condition': {
        'regexFilter': item.into,
        'resourceTypes': [
          'csp_report', 'font', 'image', 'main_frame', 'media', 'object', 'other', 'ping', 'script',
          'stylesheet', 'sub_frame', 'webbundle', 'websocket', 'webtransport', 'xmlhttprequest'
        ]
      }
    }]
  })
}

