GoRes
=====

An url redirect tool. 

Learn from ReRes and Fiddler. Thanks for their great work, especially ReRes. https://chrome.google.com/webstore/detail/reres/gieocpkbblidnocefjakldecahgeeica?hl=zh-CN&gl=CN
