<template>
    <left @node-click="nodeClick"/>
    <right :node="node"/>
</template>
<script setup>
    const node = ref({})
    const nodeClick = (data)=>{
        node.value = data
    }
</script>