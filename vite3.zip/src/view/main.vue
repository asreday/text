<template>
    <div>{{num}}</div>
</template>
<script setup>
    const num = ref(1)
</script>