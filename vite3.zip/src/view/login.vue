<template>
    <div>{{name}}</div>
    <div>{{num}}</div>
</template>
<script setup>
    const num = ref(1)
    const name = ref('login')
</script>