import { createRouter, createWebHistory } from "vue-router";
const routes = [{
    path:'/',
    redirect:'/home'
},{
    path:'/main',
    name:'main',
    component:()=>import('@/view/main')
},{
    path:'/home',
    name:'home',
    component:()=>import('@/view/home')
},{
    path:'/login',
    name:'login',
    component:()=>import('@/view/login')
}];
const router = createRouter({
  routes,
  history: createWebHistory(),
});

export default router;
