<template>
    <div>{{node.label}}</div>
    <el-input v-model="node2.label"></el-input>
    <el-button @click="changeText">修改</el-button>
</template>
<script setup>
const props = defineProps({
    node: Object,
})
// 接收
const node = computed(() => {
    return {
        ...props.node
    }
})
// 如何修改让父组件传入的值不影响父组件值
const node2 = ref('')
// const node2 = toRef(props,'node')

watch(props,(value)=>{
    node2.value = JSON.parse(JSON.stringify(value.node))
    console.log(JSON.parse(JSON.stringify(props.node)))
})

const changeText = () => {
    
    console.log((node))
}
</script>