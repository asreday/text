<template>
    <div>{{num}}</div>
    <el-button type="warning" @click="add">警告</el-button>
</template>
<script setup name="tree">
const num = ref(0)
const add = ()=>{
    num.value ++ 
}
</script>