import {
    defineConfig
} from "vite";
import path from "path";
import proxy from "./build/proxy";
import vue from "@vitejs/plugin-vue";
import AutoImport from "unplugin-auto-import/vite";
import Components from "unplugin-vue-components/vite";
import {
    ElementPlusResolver
} from "unplugin-vue-components/resolvers";
import {
    createStyleImportPlugin,
    ElementPlusResolve,
} from "vite-plugin-style-import";
import vueSetupExtend from "vite-plugin-vue-setup-extend";
import ViteRestart from "vite-plugin-restart";

// https://vitejs.dev/config/
export default defineConfig({
    server: {
        host: "localhost",
        https: true, //是否开启https
        cors: true, //默认允许任何源
        force: true, //是否强制依赖预构建
        proxy,
    },
    configureWepack: {
        devtool: 'source-map'
    },
    resolve: {
        alias: {
            "~": path.resolve(__dirname, "./"),
            "@": path.resolve(__dirname, "./src"),
        },
        extensions: [".vue", ".js", ".css", ".json"],
    },
    build: {
        chunkSizeWarningLimit: 2000, // 提高超大静态资源警告大小
        // 构建后是否生成 source map 文件。
        sourcemap: false,
        terserOptions: {
            // 清除console和debugger
            compress: {
                drop_console: true,
                drop_debugger: true,
            },
        },
        rollupOptions: {
            input: 'index.html',
            output: {
                // 静态资源打包做处理
                chunkFileNames: 'static/js/[name]-[hash].js',
                entryFileNames: 'static/js/[name]-[hash].js',
                assetFileNames: 'static/[ext]/[name]-[hash].[ext]',
                manualChunks(id) {
                    if (id.includes('node_modules')) {
                        return id.toString().split('node_modules/')[1].split('/')[0].toString();
                    }
                }
            }
        }
    },
    configureWebpack: {
        ...(process.env.ENV === 'development' ?
            {
                devtool: 'eval-source-map',
                output: {
                    devtoolModuleFilenameTemplate: (info) =>
                        info.resourcePath.match(/^\.\/\S*?\.vue$/) ?
                        `webpack-generatedCode:///${info.resourcePath}?${info.hash}` :
                        `webpack-originalCode:///${info.resourcePath}`,
                    devtoolFallbackModuleFilenameTemplate: 'webpack:///[resource-path]?[hash]'
                }
            } :
            {
                devtool: 'eval'
            }),

    },
    plugins: [
        vue(),
        vueSetupExtend(),
        // 自动引入hooks
        AutoImport({
            imports: ["vue", "vue-router", "vuex"],
            dts: "src/auto-import.d.ts",
        }),
        //自动导入组件
        Components({
            dirs: ["src/components"], //目标目录
            extensions: ["vue", "jsx"], //文件类型
            dts: "src/components.d.ts", //输出文件
            resolvers: [ElementPlusResolver()], //自动引入elementui组件
        }),
        // 引入组件弹出导致演示不生效
        createStyleImportPlugin({
            resolves: [ElementPlusResolve()],
        }),
        // 修改配置文件自动重启
        ViteRestart({
            restart: ["my.config.[jt]s"],
        }),
    ],
});